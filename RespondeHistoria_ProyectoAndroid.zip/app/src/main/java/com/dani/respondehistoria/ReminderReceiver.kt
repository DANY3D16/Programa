package com.dani.respondehistoria

import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val user = intent.getStringExtra("username") ?: "usuario"
        val note = intent.getStringExtra("storyNote") ?: ""
        val message = intent.getStringExtra("message") ?: ""
        val open = Intent(context, MainActivity::class.java).apply {
            putExtra("reply_id", id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(context, id, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val text = if (note.isBlank()) "Abre Instagram y busca la historia seleccionada." else "Historia: $note"
        val notification = Notification.Builder(context, "replies")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Hora de responder a @$user")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText("$text\nMensaje preparado: $message"))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .addAction(android.R.drawable.ic_menu_edit, "Preparar mensaje", pending)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(id, notification)
    }
}
