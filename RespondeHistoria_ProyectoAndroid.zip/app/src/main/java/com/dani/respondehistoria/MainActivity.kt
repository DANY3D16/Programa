package com.dani.respondehistoria

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.DateFormat
import java.util.Calendar
import org.json.JSONArray
import org.json.JSONObject

data class PlannedReply(
    val id: Int,
    val username: String,
    val storyNote: String,
    val message: String,
    val at: Long
)

class MainActivity : Activity() {
    private lateinit var username: EditText
    private lateinit var storyNote: EditText
    private lateinit var message: EditText
    private lateinit var whenText: TextView
    private lateinit var list: LinearLayout
    private var scheduledAt: Long = System.currentTimeMillis() + 60_000
    private val prefs by lazy { getSharedPreferences("planned_replies", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        askNotificationPermission()
        showScreen()
        intent.getIntExtra("reply_id", -1).takeIf { it >= 0 }?.let { id ->
            loadReply(id)?.let { reply ->
                message.setText(reply.message)
                username.setText(reply.username)
                storyNote.setText(reply.storyNote)
            }
        }
    }

    private fun showScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFFFFBFE.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(outer)
        setContentView(scroll)

        outer.addView(TextView(this).apply {
            text = "Responde Historia"
            textSize = 27f
            setTextColor(0xFF542A73.toInt())
            typeface = Typeface.DEFAULT_BOLD
        })
        outer.addView(TextView(this).apply {
            text = "Programa un recordatorio para responder manualmente a una historia."
            textSize = 15f
            setPadding(0, 8, 0, 20)
        })

        username = field(outer, "Usuario de Instagram (ej. @usuario)")
        storyNote = field(outer, "Referencia de la historia (ej. foto en la playa)")
        message = field(outer, "Mensaje personalizado")
        message.minLines = 3
        message.gravity = android.view.Gravity.TOP
        whenText = TextView(this).apply {
            textSize = 16f
            setPadding(0, 16, 0, 12)
        }
        outer.addView(whenText)
        button(outer, "Elegir fecha y hora") { chooseDateTime() }
        updateWhenText()
        button(outer, "Guardar recordatorio") { saveReply() }
        outer.addView(TextView(this).apply {
            text = "Tus respuestas programadas"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 24, 0, 8)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(list)
        refreshList()
    }

    private fun field(parent: LinearLayout, hintText: String): EditText {
        val e = EditText(this).apply {
            hint = hintText
            textSize = 16f
            setSingleLine(false)
            setPadding(12, 8, 12, 8)
        }
        parent.addView(e, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 8
        })
        return e
    }

    private fun button(parent: LinearLayout, title: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = title; setOnClickListener { action() } })
    }

    private fun chooseDateTime() {
        val c = Calendar.getInstance().apply { timeInMillis = scheduledAt }
        DatePickerDialog(this, { _, y, m, d ->
            TimePickerDialog(this, { _, h, min ->
                val chosen = Calendar.getInstance().apply {
                    set(Calendar.YEAR, y); set(Calendar.MONTH, m); set(Calendar.DAY_OF_MONTH, d)
                    set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (chosen.timeInMillis <= System.currentTimeMillis()) {
                    toast("Elige una hora futura.")
                } else {
                    scheduledAt = chosen.timeInMillis
                    updateWhenText()
                }
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateWhenText() {
        whenText.text = "Fecha y hora: " + DateFormat.getDateTimeInstance(
            DateFormat.MEDIUM, DateFormat.SHORT
        ).format(scheduledAt)
    }

    private fun saveReply() {
        val user = username.text.toString().trim().removePrefix("@")
        val note = storyNote.text.toString().trim()
        val msg = message.text.toString().trim()
        if (user.isBlank() || msg.isBlank()) {
            toast("Escribe el usuario y el mensaje.")
            return
        }
        if (scheduledAt <= System.currentTimeMillis()) {
            toast("Elige una hora futura.")
            return
        }
        val id = (prefs.getInt("next_id", 1))
        prefs.edit().putInt("next_id", id + 1).apply()
        val reply = PlannedReply(id, user, note, msg, scheduledAt)
        saveReplyData(reply)
        schedule(reply)
        username.text.clear()
        storyNote.text.clear()
        message.text.clear()
        scheduledAt = System.currentTimeMillis() + 60_000
        updateWhenText()
        refreshList()
        toast("Recordatorio guardado.")
    }

    private fun allReplies(): MutableList<PlannedReply> {
        val arr = JSONArray(prefs.getString("items", "[]"))
        val out = mutableListOf<PlannedReply>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(PlannedReply(o.getInt("id"), o.getString("username"),
                o.optString("storyNote"), o.getString("message"), o.getLong("at")))
        }
        return out
    }

    private fun saveReplyData(reply: PlannedReply) {
        val arr = JSONArray()
        (allReplies() + reply).forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("username", r.username)
                .put("storyNote", r.storyNote).put("message", r.message).put("at", r.at))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun loadReply(id: Int): PlannedReply? = allReplies().firstOrNull { it.id == id }

    private fun schedule(reply: PlannedReply) {
        val intent = Intent(this, ReminderReceiver::class.java).apply {
            putExtra("id", reply.id)
            putExtra("username", reply.username)
            putExtra("storyNote", reply.storyNote)
            putExtra("message", reply.message)
        }
        val pi = PendingIntent.getBroadcast(this, reply.id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:$packageName")))
                alarm.set(AlarmManager.RTC_WAKEUP, reply.at, pi)
            } else {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reply.at, pi)
            }
        } catch (_: Exception) {
            alarm.set(AlarmManager.RTC_WAKEUP, reply.at, pi)
        }
    }

    private fun refreshList() {
        list.removeAllViews()
        val replies = allReplies().sortedBy { it.at }
        if (replies.isEmpty()) {
            list.addView(TextView(this).apply { text = "Todavía no has programado respuestas." })
            return
        }
        replies.forEach { r ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(0xFFF0E7F6.toInt())
            }
            card.addView(TextView(this).apply {
                text = "@${r.username}  ·  " + DateFormat.getDateTimeInstance(
                    DateFormat.SHORT, DateFormat.SHORT).format(r.at)
                typeface = Typeface.DEFAULT_BOLD
                textSize = 16f
            })
            if (r.storyNote.isNotBlank()) card.addView(TextView(this).apply { text = "Historia: ${r.storyNote}" })
            card.addView(TextView(this).apply { text = "Mensaje: ${r.message}"; setPadding(0, 6, 0, 6) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(Button(this).apply {
                text = "Copiar mensaje"
                setOnClickListener {
                    (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("Respuesta Instagram", r.message))
                    toast("Mensaje copiado.")
                }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Abrir perfil"
                setOnClickListener { openInstagram(r.username) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = "Eliminar"
                setOnClickListener { deleteReply(r.id); refreshList() }
            })
            card.addView(row)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
    }

    private fun deleteReply(id: Int) {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        val i = Intent(this, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, id, i,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) alarm.cancel(pi)
        val arr = JSONArray()
        allReplies().filter { it.id != id }.forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("username", r.username)
                .put("storyNote", r.storyNote).put("message", r.message).put("at", r.at))
        }
        prefs.edit().putString("items", arr.toString()).apply()
        toast("Recordatorio eliminado.")
    }

    private fun openInstagram(user: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/$user/"))
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/")))
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("replies", "Respuestas programadas",
                NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Recordatorios para responder historias de Instagram"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
