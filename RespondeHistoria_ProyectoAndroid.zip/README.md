# Responde Historia (Android)

Proyecto inicial para una aplicación Android semiautomática de recordatorios de respuestas personalizadas a historias de Instagram.

## Qué hace
- Guarda manualmente el usuario, una nota que identifique la historia, el mensaje y la fecha/hora.
- Programa un recordatorio local.
- En la hora programada muestra una notificación.
- Permite copiar el mensaje y abrir el perfil de Instagram.
- No inicia sesión en Instagram, no lee historias y no envía mensajes automáticamente.

## Crear el APK
Este entorno no incluye Android SDK ni Gradle, así que no se ha compilado aquí un APK verificable.

### Opción A: Android Studio
1. Instala Android Studio en un ordenador.
2. Abre la carpeta `RespondeHistoria`.
3. Espera la sincronización de Gradle.
4. Usa **Build > Build APK(s)**.
5. El APK de depuración aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B: compilar en GitHub Actions
1. Sube el contenido de este proyecto a un repositorio de GitHub.
2. Abre la pestaña **Actions** y ejecuta el flujo `Build APK`.
3. Descarga el artefacto `responde-historia-debug-apk` al terminar.

## Limitaciones
- La nota de historia es manual; no se guarda un enlace profundo a la historia de otra cuenta.
- El recordatorio depende de los permisos de notificaciones y alarmas de Android.
- En Android 12+, puede ser necesario permitir "Alarmas y recordatorios".
- En Honor/MagicOS, la optimización de batería puede retrasar notificaciones; si pasa, permite actividad en segundo plano para esta app.
- El APK de depuración no está firmado para distribución pública.
